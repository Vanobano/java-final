package com.example.demo5;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.io.IOException;

public class HelloApplication extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        HBox paneForButtons = new HBox(20);
        Button InsertButton = new Button("insert");
        paneForButtons.getChildren().addAll(InsertButton);
        paneForButtons.setAlignment(Pos.CENTER);

        BorderPane pane = new BorderPane();
        pane.setBottom(paneForButtons);

        Label NameLabel = new Label("Name");
        TextField NameField = new TextField();

        Label CostLabel = new Label("Cost");
        TextField CostField = new TextField();

        Label WeigthLabel = new Label("Weigth ");
        TextField WeigthField = new TextField();

        Label QuantityLabel = new Label("Quantity");
        TextField QuantityField = new TextField();

        Label Due_toLabel = new Label("Due_to");
        TextField Due_toField = new TextField() ;

        Label IDLabel = new Label("ID");
        TextField IDfield = new TextField() ;

        Label ManufacturerLabel = new Label("Manufacturer");
        TextField ManufacturerField = new TextField();
        InsertButton.setOnAction(e -> {


                    String GetName = NameField.getText();
                    double GetCost = Double.parseDouble(CostField.getText());
                    double GetWight = Double.parseDouble(WeigthField.getText());
                    int GetQuantity = Integer.parseInt(QuantityField.getText());
                    String GetDue_to = Due_toField.getText();
                    String GetManufacturer = ManufacturerField.getText();
                    String GetID = IDfield.getText();


                    SQL_Connection.insert(GetName, GetCost, GetWight, GetQuantity, GetDue_to, GetManufacturer,GetID);

                }

        );

        GridPane root = new GridPane();
        root.setHgap(10);
        root.setVgap(10);
        root.addRow(0,new Label("Name"),NameField);
        root.addRow(1,new Label("Cost"),CostField);
        root.addRow(2,new Label("Weight"),WeigthField);
        root.addRow(3,new Label("Quantity"),QuantityField);
        root.addRow(4,new Label("Due_to"),Due_toField);
        root.addRow(5,new Label("Manufacturer"),ManufacturerField);
        root.addRow(6,new Label("ID"),IDfield);
        pane.setCenter(root);
        Scene scene = new Scene(pane, 800, 300);
        stage.setTitle("Product selection!!");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        SQL_Connection.setConnection();
        launch();
        SQL_Connection.disconnect();
    }
}