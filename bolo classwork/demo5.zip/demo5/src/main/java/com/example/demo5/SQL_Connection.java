package com.example.demo5;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class SQL_Connection {
    private static Connection connection ;

    private static Statement statement;

    private static final String url = "jdbc:mysql://localhost:3306/shop";
    private static final String user = "root";
    private static final String password = "";

    public static void setConnection()
    {
        try{
           connection = DriverManager.getConnection(url,user,password);
           statement=connection.createStatement();
        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Failed to establish a database connection.");
        }
    }
    public static void disconnect(){
        try{
            if(statement!=null){
                statement.close();
            }
            if (connection != null ){
                connection.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public static void exec (String sql ){
        if(statement != null){
            try {
                statement.executeUpdate(sql);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    public static void insert(String Name  , double Cost ,double Weigth  , int Quantity
            , String  Due_to  , String Manufacturer,String ID){

        String sql = "INSERT INTO Product(Name, Cost,Weigth,Quantity,Due_to,Manufacturer,ID) " +
                "VALUES ('" + Name + "', '" + Cost + "', '" + Weigth + "', '" + Quantity + "', '" +
                Due_to + "', '" + Manufacturer +"', '"+ID+"')";
        exec(sql);
    }



}
